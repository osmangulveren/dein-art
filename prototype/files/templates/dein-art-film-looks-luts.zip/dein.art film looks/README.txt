Eight film looks as 33-point .cube LUTs, made by dein.art and released under CC0 (public domain).
Use them in Premiere Pro (Lumetri > Creative > Look), After Effects (Lumetri or Apply Color LUT), DaVinci Resolve (LUTs folder), Final Cut Pro (Custom LUT effect), Edius (Primary Color Correction > LUT) or Photoshop (Color Lookup).
Preview photo: Dresden, Zwinger and Sophienkirche, Detroit Publishing Co. photochrom (public domain).
