dein.art silent film intertitles — made by dein.art, released under CC0 (public domain).
Each design comes as an editable SVG (change the text in Illustrator, Affinity, Figma or Inkscape) and a 1920x1080 PNG with a transparent background for Premiere Pro, DaVinci Resolve, Final Cut Pro, Edius, After Effects or any editor.
